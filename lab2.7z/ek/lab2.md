Microsoft Word 2007+
Dokaz1\file1 Microsoft Word 2007+
Dokaz1\file2.txt ASCII text, with no line terminators
Dokaz1\file3 PDF document, version 1.5

------------- Dokaz2\test.txt -------------
098f6bcd4621d373cade4e832627b4f6
a94a8fe5ccb19ba61c4c0873d391e987982fbbd3
9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08
------------- Dokaz2\test1.txt -------------
0cbc6611f5540bd0809a388dc95a615b
640ab2bae07bedc4c163f679a746f7ab7fb5d1fa
532eaabd9574880dbf76b9b8cc00832c20a6ec113d682299550d7a6e0f345e25

------------- Dokaz3\test.docx -------------
d41d8cd98f00b204e9800998ecf8427e
da39a3ee5e6b4b0d3255bfef95601890afd80709
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
------------- Dokaz3\test.jpg -------------
d41d8cd98f00b204e9800998ecf8427e
da39a3ee5e6b4b0d3255bfef95601890afd80709
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855

---------- Dokaz4\Secret_file_52.jpg ----------
Dokaz4\Secret_file_52.jpg PDF document, version 1.3